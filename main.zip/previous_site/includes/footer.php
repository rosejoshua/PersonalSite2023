<div class="footer" id="footer">
  <h2>© <?php echo date('Y'); ?> All rights reserved.</h2>
</div>
